# Simple Java Project
This is a demo project that you can use with [Buddy Continuous Deployment](https://buddy.works).
